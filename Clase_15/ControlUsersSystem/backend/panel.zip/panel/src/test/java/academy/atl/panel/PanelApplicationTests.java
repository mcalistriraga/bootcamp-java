package academy.atl.panel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PanelApplicationTests {

	@Test
	void contextLoads() {
	}

}
